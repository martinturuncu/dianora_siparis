<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AyarController extends Controller
{
    public function index()
    {
        // 1. Genel Ayarları Çek (Yoksa Oluştur)
        $ayar = DB::table('Ayarlar')->first();

        if (!$ayar) {
            DB::table('Ayarlar')->insert([
                'altin_fiyat' => 0, 'ayar' => 585, 'iscilik' => 0,
                'kargo' => 0, 'kutu' => 0, 'reklam' => 0, 'komisyon' => 0, 'kdv' => 0,
                'altin_usd' => 0, 'dolar_kuru' => 0,
                'etsy_ship_cost' => 0, 'etsy_usa_tax_rate' => 0, 'kargo_yurtdisi' => 0,
                'created_at' => now(), 'updated_at' => now(),
            ]);
            $ayar = DB::table('Ayarlar')->first();
        }

        // 2. Pazaryerlerini Çek (İkinci sekme için gerekli)
        $pazaryerleri = DB::table('Pazaryerleri')->orderBy('id', 'asc')->get();

        // İki veriyi de view'a gönderiyoruz
        return view('ayarlar.index', compact('ayar', 'pazaryerleri'));
    }

    public function guncelle(Request $request)
    {
        DB::table('Ayarlar')->update([
            'altin_fiyat' => $request->altin_fiyat,
            'ayar'        => $request->ayar,
            'iscilik'     => $request->iscilik,
            'kargo'       => $request->kargo,
            'kutu'        => $request->kutu,
            'reklam'      => $request->reklam,
            'kdv'         => $request->kdv,
            'altin_usd'         => $request->altin_usd,
            'dolar_kuru'        => $request->dolar_kuru,
            'etsy_ship_cost'    => $request->etsy_ship_cost,
            'etsy_usa_tax_rate' => $request->etsy_usa_tax_rate,
            'kargo_yurtdisi'    => $request->kargo_yurtdisi,
            'updated_at' => now(),
        ]);

        return redirect()->route('ayarlar.index')->with('success', 'Genel ayarlar başarıyla güncellendi!');
    }
}