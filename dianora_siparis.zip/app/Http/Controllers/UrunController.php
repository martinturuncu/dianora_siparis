<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class UrunController extends Controller
{
public function detay($siparis_id, $stok_kodu)
{
    // 1. Ürün ve Sipariş Bilgilerini Çek
    $urun = DB::connection('sqlsrv')->table('SiparisUrunleri as u')
        ->leftJoin('Urunler as ur', 'u.StokKodu', '=', 'ur.UrunKodu')
        ->leftJoin('Kategoriler as k', 'ur.KategoriId', '=', 'k.Id')
        ->leftJoin('Siparisler as s', 's.SiparisID', '=', 'u.SiparisID')
        ->leftJoin('Pazaryerleri as p', 'p.id', '=', 's.PazaryeriID')
        ->select(
            'u.*',
            'ur.Gram',
            'k.KategoriAdi',
            's.PazaryeriID',
            's.Tarih',
            's.isUSA',
            'p.Ad as PazaryeriAdi',
            'p.KomisyonOrani as PazarKomisyon'
        )
        ->where('u.SiparisID', $siparis_id)
        ->where('u.StokKodu', $stok_kodu)
        ->first();

    if (!$urun) {
        return back()->with('hata', 'Ürün bulunamadı.');
    }

    // 2. Ayarları ve Hesaplamayı Yap
    $ayar = DB::connection('sqlsrv')->table('Ayarlar')->first();
    $sonuclar = app('App\Services\KarHesapService')->hesapla($urun, $ayar);

    // 3. 🔥 EKSTRALARI ÇEK (YENİ EKLENEN KISIM)
    // Siparişe ait toplam ek gelir ve gideri hesaplıyoruz.
    $ekstralar = DB::connection('sqlsrv')->table('SiparisEkstralar')
        ->where('SiparisID', $siparis_id)
        ->selectRaw("
            SUM(CASE WHEN Tur = 'GELIR' THEN Tutar ELSE 0 END) as ToplamGelir,
            SUM(CASE WHEN Tur = 'GIDER' THEN Tutar ELSE 0 END) as ToplamGider
        ")
        ->first();

    // View'a 'ekstralar' değişkenini de gönderiyoruz
    return view('urunler.detay', compact('urun', 'ayar', 'sonuclar', 'ekstralar'));
}





public function siparisGuncelleVeKar()
{
    try {
        // 1) EXE çalıştır (sipariş güncelleme)
        $path = base_path('ConsoleApp4.exe');

        if (!File::exists($path)) {
            return back()->with('hata', 'ConsoleApp4.exe bulunamadı!');
        }

        shell_exec('start "" "' . $path . '"');

        // 2) Ayarları çek
        $ayar = DB::connection('sqlsrv')->table('Ayarlar')->first();

        // 3) Tüm ürünleri çek
        $urunler = DB::connection('sqlsrv')->table('SiparisUrunleri as u')
            ->leftJoin('Urunler as ur', 'u.StokKodu', '=', 'ur.UrunKodu')
            ->leftJoin('Kategoriler as k', 'ur.KategoriId', '=', 'k.Id')
            ->leftJoin('Siparisler as s', 's.SiparisID', '=', 'u.SiparisID')
            ->leftJoin('Pazaryerleri as p', 'p.id', '=', 's.PazaryeriID')
            ->select(
                'u.*',
                'ur.Gram',
                'k.KategoriAdi',
                's.PazaryeriID',
                's.Tarih',
                's.isUSA',
                's.SiparisDurumu', // Durumu kontrol etmek için ekledik
                'p.Ad as PazaryeriAdi',
                'p.KomisyonOrani as PazarKomisyon'
            )
            ->get();

        // 4) Servisi çağır
        $service = app('App\Services\KarHesapService');

        foreach ($urunler as $urun) {
            
            // 🔥 EĞER SİPARİŞ İPTAL İSE (DURUM 8), KÂRI 0 YAP
            if ($urun->SiparisDurumu == 8) {
                DB::connection('sqlsrv')->table('SiparisKarlar')->updateOrInsert(
                    ['SiparisID' => $urun->SiparisID, 'UrunKodu' => $urun->StokKodu],
                    ['GercekKar' => 0, 'HesapTarihi' => now()]
                );
                continue; // Diğer hesaplamaları atla, sıradaki ürüne geç
            }

            // İptal değilse normal hesapla
            $service->hesapla($urun, $ayar);
        }

        return back()->with('basarili', 'Siparişler güncellendi ve tüm kâr hesapları yeniden hesaplandı!');
    } catch (\Exception $e) {
        return back()->with('hata', 'Hata: ' . $e->getMessage());
    }
}

}