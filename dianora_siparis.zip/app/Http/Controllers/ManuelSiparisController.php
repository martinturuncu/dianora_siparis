<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ManuelSiparisController extends Controller
{
    public function create()
    {
        $pazaryerleri = DB::connection('sqlsrv')
            ->table('Pazaryerleri')
            ->orderBy('Ad')
            ->get();

        return view('siparisler.manuel_ekle', compact('pazaryerleri'));
    }


    public function store(Request $request)
    {
        // 1) VALIDATION
        $validated = $request->validate([
            'AdiSoyadi'   => 'required|string|max:200',
            'Telefon'     => 'nullable|string|max:50',
            'Adres'       => 'nullable|string',
            'PazaryeriID' => 'required|exists:Pazaryerleri,id',
            'UrunKodu'    => 'required|string|max:100',
            'SatisFiyati' => 'required|numeric|min:0',
            'Adet'        => 'required|integer|min:1',
        ]);

        $ayar = DB::connection('sqlsrv')->table('Ayarlar')->first();

        // 2) ÜRÜNÜ BUL — T001 / t001 → T001-yeni
        $girilen = strtoupper($validated['UrunKodu']); // normalize

        $urun = DB::connection('sqlsrv')
            ->table('Urunler as ur')
            ->leftJoin('Kategoriler as k', 'ur.KategoriId', '=', 'k.Id')
            ->where('ur.UrunKodu', 'LIKE', $girilen . '%')
            ->select('ur.Gram', 'ur.UrunKodu', 'k.KategoriAdi')
            ->first();

        if (!$urun) {
            return back()->with('hata', 'Ürün bulunamadı, doğru stok kodu girdiğinizden emin olun.');
        }

        // 3) MANUEL SİPARİŞ ID OLUŞTUR
        $prefix = "M";

        $sonManuel = DB::connection('sqlsrv')
            ->table('Siparisler')
            ->where('SiparisID', 'LIKE', $prefix . '%')
            ->orderBy('SiparisID', 'desc')
            ->select('SiparisID')
            ->first();

        if ($sonManuel) {
            $num = (int) substr($sonManuel->SiparisID, strlen($prefix));
            $yeniNumara = $num + 1;
        } else {
            $yeniNumara = 1;
        }

        $yeniSiparisID = $prefix . str_pad($yeniNumara, 5, '0', STR_PAD_LEFT);

        // 4) TARİH — datetime-local düzeltme
        if ($request->filled('Tarih')) {
            $tarih = str_replace('T', ' ', $request->Tarih) . ':00';
        } else {
            $tarih = now()->format('Y-m-d H:i:s');
        }

        // 5) SİPARİŞ KAYDET
        DB::connection('sqlsrv')
            ->table('Siparisler')
            ->insert([
                'SiparisID'     => $yeniSiparisID,
                'AdiSoyadi'     => $validated['AdiSoyadi'],
                'Telefon'       => $validated['Telefon'] ?? '',
                'Email'         => '',
                'Adres'         => $validated['Adres'] ?? '',
                'Il'            => '',
                'Ilce'          => '',
                'Tarih'         => $tarih,
                'PazaryeriID'   => $validated['PazaryeriID'],
                'SiparisDurumu' => 1,
                'Onaylandi'     => 0,
                'isUSA'         => $request->has('isUSA') ? 1 : 0,
            ]);

        // 6) ÜRÜN SATIRI
        $adet  = (int)$validated['Adet'];
        $birim = (float)$validated['SatisFiyati'];

        // Etsy fiyat → USD → TL
        if ($validated['PazaryeriID'] == 3) {
            $birim = $birim * $ayar->dolar_kuru;
        }

        $tutar = $birim * $adet;

        DB::connection('sqlsrv')
            ->table('SiparisUrunleri')
            ->insert([
                'SiparisID'  => $yeniSiparisID,
                'StokKodu'   => $urun->UrunKodu,   // T001-yeni → gerçek kod
                'UrunAdi'    => $urun->KategoriAdi ?? 'Ürün',
                'Miktar'     => $adet,
                'BirimFiyat' => $birim,
                'Tutar'      => $tutar,
                'KdvTutari'  => 0,
            ]);

        return redirect()
            ->route('siparisler.index')
            ->with('success', 'Manuel sipariş başarıyla oluşturuldu!');
    }
}
