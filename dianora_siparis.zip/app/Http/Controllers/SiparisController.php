<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class SiparisController extends Controller
{
   public function index(Request $request)
{
    // Arama kelimesini al
    $search = $request->input('search');

    // Temel SQL Sorgusu (WHERE kısmını dinamik yapacağız)
    $sql = "
        SELECT 
            s.SiparisID,
            s.AdiSoyadi AS MusteriAdi, 
            s.PazaryeriID,
            p.Ad AS PazaryeriAd,
            p.KomisyonOrani AS KomisyonOrani,
            FORMAT(s.Tarih, 'dd.MM.yyyy HH:mm:ss', 'tr-TR') AS SiparisTarihi,
            s.SiparisDurumu,
            
            u.UrunAdi,
            u.StokKodu, 
            k.KategoriAdi AS UrunKategori,
            ur.Gram AS UrunGram,
            u.Miktar, 
            u.Tutar, 
            u.KdvTutari,

            CASE 
                WHEN ur.Gram IS NULL OR ur.Gram = 0 THEN NULL
                ELSE ISNULL(sk.GercekKar, 0)
            END AS GercekKar

        FROM Siparisler s
        INNER JOIN SiparisUrunleri u ON s.SiparisID = u.SiparisID
        
        LEFT JOIN Urunler ur ON (
            ur.UrunKodu = u.StokKodu 
            OR ur.UrunKodu = u.StokKodu + '-yeni'
            OR u.StokKodu = ur.UrunKodu + '-yeni'
        )

        LEFT JOIN Kategoriler k ON ur.KategoriID = k.Id

        LEFT JOIN SiparisKarlar sk ON sk.SiparisID = s.SiparisID AND (
            sk.UrunKodu = u.StokKodu
            OR sk.UrunKodu = u.StokKodu + '-yeni'
            OR u.StokKodu = sk.UrunKodu + '-yeni'
        )

        LEFT JOIN Pazaryerleri p ON p.id = s.PazaryeriID
        
        WHERE s.AdiSoyadi != 'Dianora Piercing'
    ";

    $bindings = [];

    // 🔍 EĞER ARAMA VARSA SQL'E EKLE
    if ($search) {
        $sql .= " AND (
            s.SiparisID LIKE ? OR 
            s.AdiSoyadi LIKE ? OR 
            u.UrunAdi LIKE ? OR 
            u.StokKodu LIKE ? OR
            p.Ad LIKE ?
        )";
        
        $searchTerm = '%' . $search . '%';
        // Her ? işareti için parametreyi ekliyoruz
        $bindings = [$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm];
    }

    // Sıralamayı en sona ekle
    $sql .= " ORDER BY s.Tarih DESC";

    // Sorguyu çalıştır
    $siparisler = DB::connection('sqlsrv')->select($sql, $bindings);

    return view('siparisler.index', compact('siparisler'));
}
    public function destroy($id)
    {
        // Siparişi sil
        DB::connection('sqlsrv')->table('Siparisler')
            ->where('SiparisID', $id)
            ->delete();

        // Sipariş ürünlerini sil
        DB::connection('sqlsrv')->table('SiparisUrunleri')
            ->where('SiparisID', $id)
            ->delete();

        return back()->with('success', 'Manuel sipariş başarıyla silindi!');
    }

    // 🟢 Manuel Sipariş Durumu Güncelleme
    public function durumGuncelle(Request $request, $id)
    {
        $siparis = DB::connection('sqlsrv')->table('Siparisler')->where('SiparisID', $id)->first();

        if (!$siparis) {
            return back()->with('hata', 'Sipariş bulunamadı.');
        }

        $yeniDurum = $request->input('durum');

        DB::connection('sqlsrv')->table('Siparisler')
            ->where('SiparisID', $id)
            ->update(['SiparisDurumu' => $yeniDurum]);

        return back()->with('success', 'Sipariş durumu güncellendi.');
    }

    public function istatistikler(Request $request)
    {
        // Varsayılan Tarihler
        $tarih     = $request->input('tarih', now()->toDateString());
        $baslangic = $request->input('baslangic');
        $bitis     = $request->input('bitis');

        // ==========================================================
        // 📅 1. GÜNLÜK VERİLER
        // ==========================================================
        
        // A) Sayıları Tek Sorguda Çek
        $gunlukOzet = DB::connection('sqlsrv')->table('Siparisler')
            ->whereDate('Tarih', $tarih)
            ->where('AdiSoyadi', '!=', 'Dianora Piercing') // 🔥 FİLTRE EKLENDİ
            ->selectRaw("
                COUNT(*) as toplam,
                SUM(CASE WHEN SiparisDurumu = 8 THEN 1 ELSE 0 END) as iptal,
                SUM(CASE WHEN SiparisDurumu != 8 THEN 1 ELSE 0 END) as aktif
            ")
            ->first();

        $gunlukToplamSiparis = $gunlukOzet->toplam ?? 0;
        $gunlukIptalSayisi   = $gunlukOzet->iptal ?? 0;
        $gunlukSiparisSayisi = $gunlukOzet->aktif ?? 0;

        // B) Ürün Sayısı (Sadece İptal Olmayanlar)
        $gunlukUrunSayisi = DB::connection('sqlsrv')->table('SiparisUrunleri')
            ->join('Siparisler', 'SiparisUrunleri.SiparisID', '=', 'Siparisler.SiparisID')
            ->whereDate('Siparisler.Tarih', $tarih)
            ->where('Siparisler.SiparisDurumu', '<>', 8)
            ->where('Siparisler.AdiSoyadi', '!=', 'Dianora Piercing') // 🔥 FİLTRE EKLENDİ
            ->sum('SiparisUrunleri.Miktar');

        // C) Günlük Kâr (Sadece İptal Olmayanlar)
        $gunlukKar = DB::connection('sqlsrv')->table('SiparisKarlar')
            ->join('Siparisler', 'SiparisKarlar.SiparisID', '=', 'Siparisler.SiparisID')
            ->whereDate('Siparisler.Tarih', $tarih)
            ->where('Siparisler.SiparisDurumu', '<>', 8)
            ->where('Siparisler.AdiSoyadi', '!=', 'Dianora Piercing') // 🔥 FİLTRE EKLENDİ
            ->sum('SiparisKarlar.GercekKar');

        // D) Günlük Ciro (Sadece İptal Olmayanlar)
        $gunlukCiro = DB::connection('sqlsrv')->table('SiparisUrunleri')
            ->join('Siparisler', 'SiparisUrunleri.SiparisID', '=', 'Siparisler.SiparisID')
            ->whereDate('Siparisler.Tarih', $tarih)
            ->where('Siparisler.SiparisDurumu', '<>', 8)
            ->where('Siparisler.AdiSoyadi', '!=', 'Dianora Piercing') // 🔥 FİLTRE EKLENDİ
            ->selectRaw('SUM( (SiparisUrunleri.Tutar + SiparisUrunleri.KdvTutari) * SiparisUrunleri.Miktar ) AS ciro')
            ->value('ciro');


        // ==========================================================
        // 📆 2. TARİH ARALIĞI VERİLERİ
        // ==========================================================
        
        $aralikVerisi = null;
        $aralikCiro   = 0;

        if ($baslangic && $bitis) {
            
            if ($baslangic > $bitis) {
                [$baslangic, $bitis] = [$bitis, $baslangic];
            }

            $start = Carbon::parse($baslangic)->startOfDay();
            $end   = Carbon::parse($bitis)->endOfDay();

            // A) Aralık Özeti (Sayılar)
            $aralikOzet = DB::connection('sqlsrv')->table('Siparisler')
                ->whereBetween('Tarih', [$start, $end])
                ->where('AdiSoyadi', '!=', 'Dianora Piercing') // 🔥 FİLTRE EKLENDİ
                ->selectRaw("
                    COUNT(*) as toplam,
                    SUM(CASE WHEN SiparisDurumu = 8 THEN 1 ELSE 0 END) as iptal,
                    SUM(CASE WHEN SiparisDurumu != 8 THEN 1 ELSE 0 END) as aktif
                ")
                ->first();

            // B) Aralık Ürün Sayısı (Aktifler)
            $aralikUrunSayisi = DB::connection('sqlsrv')->table('SiparisUrunleri')
                ->join('Siparisler', 'SiparisUrunleri.SiparisID', '=', 'Siparisler.SiparisID')
                ->whereBetween('Siparisler.Tarih', [$start, $end])
                ->where('Siparisler.SiparisDurumu', '<>', 8)
                ->where('Siparisler.AdiSoyadi', '!=', 'Dianora Piercing') // 🔥 FİLTRE EKLENDİ
                ->sum('SiparisUrunleri.Miktar');

            // C) Aralık Kâr (Aktifler)
            $aralikKar = DB::connection('sqlsrv')->table('SiparisKarlar')
                ->join('Siparisler', 'SiparisKarlar.SiparisID', '=', 'Siparisler.SiparisID')
                ->whereBetween('Siparisler.Tarih', [$start, $end])
                ->where('Siparisler.SiparisDurumu', '<>', 8)
                ->where('Siparisler.AdiSoyadi', '!=', 'Dianora Piercing') // 🔥 FİLTRE EKLENDİ
                ->sum('SiparisKarlar.GercekKar');

            // D) Aralık Ciro (Aktifler)
            $aralikCiro = DB::connection('sqlsrv')->table('SiparisUrunleri')
                ->join('Siparisler', 'SiparisUrunleri.SiparisID', '=', 'Siparisler.SiparisID')
                ->whereBetween('Siparisler.Tarih', [$start, $end])
                ->where('Siparisler.SiparisDurumu', '<>', 8)
                ->where('Siparisler.AdiSoyadi', '!=', 'Dianora Piercing') // 🔥 FİLTRE EKLENDİ
                ->selectRaw('SUM( (SiparisUrunleri.Tutar + SiparisUrunleri.KdvTutari) * SiparisUrunleri.Miktar ) AS ciro')
                ->value('ciro');

            // Veriyi paketle
            $aralikVerisi = [
                'toplam' => $aralikOzet->toplam ?? 0,
                'aktif'  => $aralikOzet->aktif ?? 0,
                'iptal'  => $aralikOzet->iptal ?? 0,
                'urun'   => $aralikUrunSayisi ?? 0,
                'kar'    => $aralikKar ?? 0,
            ];
        }

        return view('siparisler.istatistikler', compact(
            'tarih', 
            'gunlukToplamSiparis', 
            'gunlukSiparisSayisi', 
            'gunlukIptalSayisi',
            'gunlukUrunSayisi', 
            'gunlukKar', 
            'gunlukCiro',
            'aralikVerisi', 
            'aralikCiro', 
            'baslangic', 
            'bitis'
        ));
    }
}