<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FiyatController extends Controller
{
    public function index()
    {
        $kategoriler = DB::connection('sqlsrv')
            ->table('Kategoriler')
            ->select('Id', 'KategoriAdi', 'KarOrani', 'KategoriKodu')
            ->orderBy('KategoriAdi')
            ->get();

        $badges = [
            1 => ['bg' => '#212529', 'text' => 'dianorapiercing.com', 'icon' => 'fa-globe', 'image' => asset('images/dianora_icon.png')],
            2 => ['bg' => '#f27a1a', 'text' => 'Trendyol', 'icon' => '', 'image' => asset('images/trendyol_icon.png')],
            3 => ['bg' => '#F1641E', 'text' => 'Etsy', 'icon' => 'fa-etsy', 'image' => ''], // Resim yok, icon var
            4 => ['bg' => '#146eb4', 'text' => 'Hipicon', 'icon' => '', 'image' => asset('images/hipicon_icon.png')],
            5 => ['bg' => '#FF6000', 'text' => 'Hepsiburada', 'icon' => 'fa-bag-shopping', 'image' => ''],
            6 => ['bg' => '#5f259f', 'text' => 'N11', 'icon' => 'fa-n', 'image' => ''],
            99 => ['bg' => '#198754', 'text' => 'Elden / Havale', 'icon' => 'fa-hand-holding-dollar', 'image' => ''],
        ];

        return view('fiyat.index', compact('kategoriler', 'badges'));
    }

    public function urunGetir(Request $request)
    {
        $kod = trim($request->urun_kodu);
        if(!$kod) return response()->json(['status' => false]);

        $urun = DB::connection('sqlsrv')->table('Urunler')
            ->where('UrunKodu', $kod)
            ->orWhere('UrunKodu', $kod . '-yeni')
            ->select('Gram', 'KategoriId', 'UrunKodu')
            ->first();

        return response()->json(['status' => (bool)$urun, 'urun' => $urun]);
    }

    public function hesapla(Request $request)
    {
        try {
            $ayar = DB::connection('sqlsrv')->table('Ayarlar')->first();
            if (!$ayar) throw new \Exception('Ayarlar tablosu bulunamadı.');

            $gram = (float) $request->gram;
            $kategoriId = $request->kategori_id;
            
            $karOrani = 0;
            if ($kategoriId) {
                $kat = DB::connection('sqlsrv')->table('Kategoriler')->where('Id', $kategoriId)->first();
                if($kat) $karOrani = $kat->KarOrani ?? 0;
            }

            $pazaryerleri = DB::connection('sqlsrv')->table('Pazaryerleri')->get();

            // --- MALİYETLER ---
            $dolarKuru = (float)$ayar->dolar_kuru;
            if($dolarKuru <= 0) $dolarKuru = 1; 
            $milyem = ($ayar->ayar > 10) ? ($ayar->ayar / 1000) : $ayar->ayar; 

            // TL Maliyeti (Vergisiz)
            $altinMaliyetiTL = round($gram * $ayar->altin_fiyat * $milyem, 2);
            $giderTL = $ayar->iscilik + $ayar->kargo + $ayar->kutu + $ayar->reklam;
            $toplamMaliyetTL = $altinMaliyetiTL + $giderTL;
            
            // USD Maliyeti (Yurtdışı Kargo ile)
            $kargoYurtdisiTL = $ayar->kargo_yurtdisi ?? 0; 
            $giderYurtdisiTL = $ayar->iscilik + $kargoYurtdisiTL + $ayar->kutu + $ayar->reklam;

            $altinMaliyetiUSD = round($gram * $ayar->altin_usd * $milyem, 2);
            $giderUSD = round($giderYurtdisiTL / $dolarKuru, 2);
            $toplamMaliyetUSD = $altinMaliyetiUSD + $giderUSD;

            // KDV
            $hamKdv = (float)($ayar->kdv ?? 0);
            $kdvOrani = ($hamKdv >= 1) ? ($hamKdv / 100) : $hamKdv;

            $sonuclar = [];

            foreach ($pazaryerleri as $pazar) {
                $pazarId = $pazar->id ?? $pazar->Id ?? 0;
                $pazarAd = $pazar->Ad ?? $pazar->ad ?? '';
                $hamKomisyon = (float)($pazar->KomisyonOrani ?? 0);
                $komisyonOrani = ($hamKomisyon >= 1) ? ($hamKomisyon / 100) : $hamKomisyon;
                if($komisyonOrani >= 0.99) $komisyonOrani = 0.99;

                $isEtsy = strtolower($pazarAd) === 'etsy';

                if ($isEtsy) {
                    // --- ETSY (USD) ---
                    $karliFiyatUSD = $toplamMaliyetUSD * (1 + ($karOrani / 100));
                    
                    // 1. ETSY USA
                    $shipEntegra = (float)$ayar->etsy_ship_cost;
                    $usaTaxRate = (float)$ayar->etsy_usa_tax_rate;
                    if($usaTaxRate >= 1) $usaTaxRate /= 100;

                    $vergiDahilFiyatUSA = ($karliFiyatUSD + $shipEntegra) / (1 - $usaTaxRate);
                    $hesaplananVergi = $vergiDahilFiyatUSA * $usaTaxRate;
                    $usaSatisFiyati = $vergiDahilFiyatUSA / (1 - $komisyonOrani);
                    $kesintiKomisyonUSA = $usaSatisFiyati * $komisyonOrani;
                    $netKarUSA = $usaSatisFiyati - $kesintiKomisyonUSA - $hesaplananVergi - $shipEntegra - $toplamMaliyetUSD;

                    $sonuclar[] = [
                        'sort_order' => 2, // USD Pazaryerleri 2. Sırada
                        'id' => $pazarId, 'ad' => 'Etsy (USA)', 'tur' => 'USD',
                        'satis_fiyati'  => number_format($usaSatisFiyati, 2),
                        'buffer_fiyati' => number_format($usaSatisFiyati * 1.10, 2),
                        'net_kar'       => number_format($netKarUSA, 2) . ' $',
                        'kur_karsiligi' => number_format($usaSatisFiyati * $dolarKuru, 2) . ' ₺',
                        'detay_altin'     => number_format($altinMaliyetiUSD, 2),
                        'detay_gider'     => number_format($giderUSD, 2),
                        'detay_komisyon'  => number_format($kesintiKomisyonUSA, 2),
                        'detay_vergi'     => number_format($hesaplananVergi, 2),
                        'detay_kargo'     => number_format($shipEntegra, 2),
                        'detay_maliyet'   => number_format($toplamMaliyetUSD, 2),
                        'maliyet_tl'      => number_format($toplamMaliyetUSD * $dolarKuru, 2),
                        'net_kar_tl'      => number_format($netKarUSA * $dolarKuru, 2),
                    ];

                    // 2. ETSY GLOBAL
                    $euSatisFiyati = $karliFiyatUSD / (1 - $komisyonOrani);
                    $kesintiKomisyonGlobal = $euSatisFiyati * $komisyonOrani;
                    $netKarGlobal = $euSatisFiyati - $kesintiKomisyonGlobal - $toplamMaliyetUSD;

                    $sonuclar[] = [
                        'sort_order' => 2,
                        'id' => $pazarId, 'ad' => 'Etsy (Diğer)', 'tur' => 'USD',
                        'satis_fiyati'  => number_format($euSatisFiyati, 2),
                        'buffer_fiyati' => number_format($euSatisFiyati * 1.10, 2),
                        'net_kar'       => number_format($netKarGlobal, 2) . ' $',
                        'kur_karsiligi' => number_format($euSatisFiyati * $dolarKuru, 2) . ' ₺',
                        'detay_altin'     => number_format($altinMaliyetiUSD, 2),
                        'detay_gider'     => number_format($giderUSD, 2),
                        'detay_komisyon'  => number_format($kesintiKomisyonGlobal, 2),
                        'detay_vergi'     => '0.00',
                        'detay_kargo'     => '0.00', 
                        'detay_maliyet'   => number_format($toplamMaliyetUSD, 2),
                        'maliyet_tl'      => number_format($toplamMaliyetUSD * $dolarKuru, 2),
                        'net_kar_tl'      => number_format($netKarGlobal * $dolarKuru, 2),
                    ];

                } else {
                    // TL PAZARYERLERİ
                    $hedefNetPara = $toplamMaliyetTL * (1 + ($karOrani / 100));
                    $kdvKatsayisi = ($kdvOrani > 0) ? ($kdvOrani / (1 + $kdvOrani)) : 0;
                    
                    $bolen = 1 - $komisyonOrani - $kdvKatsayisi;
                    if ($bolen <= 0.01) $bolen = 0.01; 

                    $pay = $hedefNetPara - ($altinMaliyetiTL * $kdvKatsayisi);
                    $satisFiyatiTL = ($pay / $bolen) * 1.02; 

                    $kesilenKomisyon = $satisFiyatiTL * $komisyonOrani;
                    $vergiMatrahiBrut = max(0, $satisFiyatiTL - $altinMaliyetiTL);
                    $hesaplananKdv = $vergiMatrahiBrut * $kdvKatsayisi;
                    $netEleGecen = $satisFiyatiTL - $kesilenKomisyon - $hesaplananKdv;
                    $netKarTL = $netEleGecen - $toplamMaliyetTL;

                    $sonuclar[] = [
                        'sort_order' => 1, // TL Pazaryerleri 1. Sırada
                        'id' => $pazarId, 'ad' => $pazarAd, 'tur' => 'TL',
                        'satis_fiyati'  => number_format($satisFiyatiTL, 2),
                        'buffer_fiyati' => number_format($satisFiyatiTL * 1.10, 2),
                        'net_kar'       => number_format($netKarTL, 2) . ' ₺',
                        'kur_karsiligi' => '-',
                        'detay_altin'     => number_format($altinMaliyetiTL, 2),
                        'detay_gider'     => number_format($giderTL, 2),
                        'detay_komisyon'  => number_format($kesilenKomisyon, 2),
                        'detay_vergi'     => number_format($hesaplananKdv, 2),
                        'detay_kargo'     => '0.00', 
                        'detay_maliyet'   => number_format($toplamMaliyetTL, 2),
                    ];
                }
            }

            // 99. ELDEN SATIŞ
            $eldenHedefNet = $toplamMaliyetTL * (1 + ($karOrani / 100));
            $eldenNetIscilik = $eldenHedefNet - $altinMaliyetiTL;
            $eldenKdvTutari = ($eldenNetIscilik > 0) ? ($eldenNetIscilik * $kdvOrani) : 0;
            $eldenSatisFiyati = $eldenHedefNet + $eldenKdvTutari;
            $eldenNetKar = $eldenHedefNet - $toplamMaliyetTL;

            $sonuclar[] = [
                'sort_order' => 3, // Elden Satış En Sonda
                'id' => 99, 'ad' => 'Elden / Havale', 'tur' => 'TL',
                'satis_fiyati'  => number_format($eldenSatisFiyati, 2),
                'ekstra_fiyat'  => number_format($eldenHedefNet, 2) . ' ₺',
                'buffer_fiyati' => number_format($eldenSatisFiyati * 1.05, 2),
                'net_kar'       => number_format($eldenNetKar, 2) . ' ₺',
                'kur_karsiligi' => '-',
                'detay_altin'     => number_format($altinMaliyetiTL, 2),
                'detay_gider'     => number_format($giderTL, 2),
                'detay_komisyon'  => '0.00',
                'detay_vergi'     => number_format($eldenKdvTutari, 2),
                'detay_kargo'     => '0.00',
                'detay_maliyet'   => number_format($toplamMaliyetTL, 2),
            ];

            // SIRALAMA İŞLEMİ: TL(1) -> USD(2) -> ELDEN(3)
            // Bu sayede Etsy kartları tabloda yan yana gelecektir.
            $sonuclar = collect($sonuclar)->sortBy('sort_order')->values()->all();

            return response()->json([
                'status' => true,
                'sonuclar' => $sonuclar,
                'meta' => [
                    'altin_tl' => number_format($ayar->altin_fiyat, 2),
                    'dolar'    => number_format($ayar->dolar_kuru, 4),
                ]
            ]);

        } catch (\Exception $e) {
            return response()->json(['status' => false, 'message' => 'Hata: ' . $e->getMessage()], 404);
        }
    }
}