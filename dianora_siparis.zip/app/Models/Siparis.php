<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Siparis extends Model
{
    protected $table = 'Siparisler';
    protected $primaryKey = 'SiparisID';
    public $timestamps = false;

    public function urunler()
    {
        return $this->hasMany(SiparisUrunleri::class, 'SiparisID', 'SiparisID');
    }
    public function pazaryeri()
{
    return $this->belongsTo(\App\Models\Pazaryeri::class, 'PazaryeriID');
}

}
