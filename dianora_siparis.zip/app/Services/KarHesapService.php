<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;

class KarHesapService
{
    /**
     * Ürün karını hesaplar ve sonucu veritabanına kaydeder.
     * Stok kodu veritabanında -yeni uzantılı olarak kayıtlı olabilir, bu durum kontrol edilir.
     * Ayrıca gramaj eksikse, alternatif stok kodlarından (H070 <-> H070-yeni) gramaj tamamlanır.
     * Hediye mantığı kaldırılmıştır; her ürün hesaplamaya dahil edilir.
     *
     * @param object $urun Sipariş ürün detayları (Tutar, KdvTutari, Miktar, Gram, StokKodu, PazaryeriID, isUSA, PazarKomisyon, SiparisID)
     * @param object $ayar Sistem ayarları (dolar_kuru, altin_usd, etsy_usa_tax_rate, etsy_ship_cost, iscilik, kutu, reklam, kargo_yurtdisi, altin_fiyat, kargo, kdv)
     * @return array Hesaplama sonuçları
     */
    public function hesapla($urun, $ayar)
    {
        // =================================================================
        // 🛠️ 0. ADIM: EKSİK GRAMAJ TAMAMLAMA
        // Sipariş kodu 'H070-yeni' ama Urunler tablosunda 'H070' varsa Gram 0 gelir.
        // Bunu düzeltmek için çapraz kontrol yapıp Gram'ı buluyoruz.
        // =================================================================
        if (!isset($urun->Gram) || $urun->Gram <= 0) {
            $aranacakKodlar = [];

            // Eğer gelen kodda "yeni" ifadesi varsa, temizleyip saf halini (H070) arayacağız.
            if (stripos($urun->StokKodu, 'yeni') !== false) {
                // '-yeni', ' yeni', '-YENİ' gibi uzantıları temizle
                $temizKod = preg_replace('/[- ]?yeni/i', '', $urun->StokKodu);
                $aranacakKodlar[] = $temizKod;
            } 
            // Eğer "yeni" yoksa, belki veritabanında "-yeni"li hali vardır (H070 -> H070-yeni)
            else {
                $aranacakKodlar[] = $urun->StokKodu . '-yeni';
                $aranacakKodlar[] = $urun->StokKodu . '-YENİ';
            }

            // Urunler tablosundan gramajı sorgula
            if (!empty($aranacakKodlar)) {
                $anaUrun = DB::connection('sqlsrv')
                    ->table('Urunler')
                    ->whereIn('UrunKodu', $aranacakKodlar)
                    ->where('Gram', '>', 0)
                    ->select('Gram')
                    ->first();

                if ($anaUrun) {
                    $urun->Gram = $anaUrun->Gram; // Bulunan gramajı ata
                }
            }
        }

        // =================================================================
        // STOK KODU KONTROL FONKSİYONU (SiparisKarlar Tablosu İçin)
        // Kayıt yaparken hangi stok kodunu kullanacağımızı belirler.
        // =================================================================
        $getStokKodu = function ($siparisId, $stokKodu) {
            $stokKoduYeni = $stokKodu . '-yeni';
            
            // 1. Veritabanında "-yeni" eklenmiş hali var mı? (Varsa onu kullan)
            $kayitYeni = DB::connection('sqlsrv')
                ->table('SiparisKarlar')
                ->where('SiparisID', $siparisId)
                ->where('UrunKodu', $stokKoduYeni)
                ->first();

            if ($kayitYeni) {
                return $stokKoduYeni; 
            }
            
            // 2. Veritabanında orijinal hali var mı? (Varsa onu kullan)
            $kayitOrijinal = DB::connection('sqlsrv')
                ->table('SiparisKarlar')
                ->where('SiparisID', $siparisId)
                ->where('UrunKodu', $stokKodu)
                ->first();

            if ($kayitOrijinal) {
                return $stokKodu; 
            }

            // 3. Hiçbiri yoksa, siparişten gelen kodu kullan (Arayüz eşleşmesi için en güvenlisi)
            return $stokKodu;
        };

        // ---------------------------------------------
        // 🔥 1) ETSY SİPARİŞİ
        // ---------------------------------------------
        if ((int)$urun->PazaryeriID === 3) {
            
            $finalStokKodu = $getStokKodu($urun->SiparisID, $urun->StokKodu);

            $miktar         = (int)$urun->Miktar;
            $gram           = (float)$urun->Gram; // Gram yoksa 0 olarak hesaplanır
            $dolarKuru      = (float)$ayar->dolar_kuru;
            $altinUSD       = (float)$ayar->altin_usd;
            $komisyonOrani  = (float)$urun->PazarKomisyon;
            $isUSA          = (int)$urun->isUSA;

            $satisUSD = $urun->Tutar / $dolarKuru;

            // Komisyon kes
            $netUSD = $satisUSD - ($satisUSD * $komisyonOrani);

            // USA vergileri
            if ($isUSA === 1) {
                $usaVergi = $netUSD * (float)$ayar->etsy_usa_tax_rate;
                $netUSD  -= $usaVergi;
                $netUSD  -= (float)$ayar->etsy_ship_cost;
            }

            // Altın maliyeti (USD)
            $altinMaliyetUSD = ($gram * $altinUSD * 0.585) * $urun->Miktar;

            // TL giderleri
            $giderTL =
                 $ayar->iscilik
               + $ayar->kutu
               + $ayar->reklam
               + $ayar->kargo_yurtdisi;

            // Giderleri USD'ye dönüştür (adet dahil)
            $giderUSD = ($giderTL / $dolarKuru) * $urun->Miktar;

            // Toplam maliyet (USD)
            $toplamMaliyetUSD = $altinMaliyetUSD + $giderUSD;

            // Kâr
            $karUSD = $netUSD - $toplamMaliyetUSD;
            $karTL  = $karUSD * $dolarKuru;

            // DB kayıt
            DB::connection('sqlsrv')->table('SiparisKarlar')->updateOrInsert(
                ['SiparisID' => $urun->SiparisID, 'UrunKodu' => $finalStokKodu],
                ['GercekKar' => $karTL, 'HesapTarihi' => now()]
            );


            return [
                'etsy'             => true,
                'pazaryeri'        => 'Etsy',
                'komisyon'         => $komisyonOrani,
                'gercekKar'        => $karTL,
                'isUSA'            => $isUSA,
                'netUSD'           => $netUSD,
                'altinMaliyetUSD'  => $altinMaliyetUSD,
                'giderUSD'         => $giderUSD,
                'toplamMaliyetUSD' => $toplamMaliyetUSD,
                'karUSD'           => $karUSD,
                'karTL'            => $karTL,
                'miktar'           => $miktar
            ];
        }

        // ---------------------------------------------
        // 🔥 2) NORMAL (TL) SİPARİŞ
        // ---------------------------------------------
        
        $finalStokKodu = $getStokKodu($urun->SiparisID, $urun->StokKodu);

        $miktar          = (int)$urun->Miktar;
        $birimNet        = (float)$urun->Tutar;
        $birimKdv        = (float)$urun->KdvTutari;
        $birimSatisKdvli = $birimNet + $birimKdv;
        $gram            = (float)$urun->Gram; // Gram yoksa 0 olarak hesaplanır

        // Maliyetler
        $altinMaliyet  = $gram * $ayar->altin_fiyat * 0.585 * $miktar;
        $gider         = ($ayar->iscilik + $ayar->kargo + $ayar->kutu + $ayar->reklam) * $miktar;
        $toplamMaliyet = $altinMaliyet + $gider;

        // KDV
        $kdvOrani = $ayar->kdv / 100;
        
        $totalSatisKdvli = $birimSatisKdvli * $miktar;
        
        $netVergiHaric = ($totalSatisKdvli - $altinMaliyet) * (1 - $kdvOrani) + $altinMaliyet;
        $vergi = $totalSatisKdvli - $netVergiHaric;
        
        // Komisyon
        $komisyon = (float)$urun->PazarKomisyon;
        $odenenKomisyon = $totalSatisKdvli * $komisyon;

        // Net satış
        $gercekNetSatisBirim = $totalSatisKdvli - ($vergi + $odenenKomisyon);
        $gercekKarToplam = $gercekNetSatisBirim - $toplamMaliyet;
        

        // Veritabanına kaydet
        DB::connection('sqlsrv')->table('SiparisKarlar')->updateOrInsert(
            ['SiparisID' => $urun->SiparisID, 'UrunKodu' => $finalStokKodu],
            ['GercekKar' => $gercekKarToplam, 'HesapTarihi' => now()]
        );

        return [
            'etsy'           => false,
            'pazaryeri'      => $urun->PazaryeriAdi,
            'komisyon'       => $komisyon,
            'gercekKar'      => $gercekKarToplam,
            'miktar'         => $miktar,
            'altinMaliyeti'  => $altinMaliyet,
            'toplamMaliyet'  => $toplamMaliyet,
            'kdvOrani'       => $kdvOrani,
            'vergi'          => $vergi,
            'odenenKomisyon' => $odenenKomisyon,
            'gercekNetSatis' => $gercekNetSatisBirim,
            'gercekSatis'    => $birimSatisKdvli * $miktar,
            'gider'          => $gider,
        ];
    }
}