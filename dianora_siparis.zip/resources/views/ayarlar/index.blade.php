@extends('layouts.app')

@section('title', 'Ayarlar Yönetimi')

@section('content')
<div class="container-fluid py-5 bg-light" style="min-height: 100vh;">

    <div class="container" style="max-width: 1000px;">
        
        {{-- BAŞLIK --}}
        <div class="text-center mb-4">
            <h3 class="fw-bold text-dark mb-1">⚙️ Ayarlar Merkezi</h3>
            <p class="text-muted small">Sistem genel ayarları ve pazaryeri komisyonlarını buradan yönetebilirsiniz.</p>
        </div>

        {{-- BİLDİRİMLER --}}
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show shadow-sm border-0 border-start border-success border-4" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @if(session('hata'))
            <div class="alert alert-danger alert-dismissible fade show shadow-sm border-0 border-start border-danger border-4" role="alert">
                <i class="fa-solid fa-circle-exclamation me-2"></i> {{ session('hata') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        {{-- GÜZEL GÖRÜNEN SEKMELER (NAV PILLS) --}}
        <div class="bg-white p-1 rounded-pill shadow-sm mb-4 d-inline-flex w-100 justify-content-center" style="border: 1px solid #e9ecef;">
            <ul class="nav nav-pills nav-fill w-100" id="settingTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active rounded-pill fw-bold py-2" id="genel-tab" data-bs-toggle="pill" data-bs-target="#genel" type="button" role="tab">
                        💰 Maliyet & Genel
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link rounded-pill fw-bold py-2" id="pazar-tab" data-bs-toggle="pill" data-bs-target="#pazar" type="button" role="tab">
                        📦 Pazaryeri & Komisyonlar
                    </button>
                </li>
            </ul>
        </div>

        {{-- SEKME İÇERİKLERİ --}}
        <div class="tab-content" id="settingTabsContent">

            {{-- TAB 1: GENEL AYARLAR --}}
            <div class="tab-pane fade show active" id="genel" role="tabpanel">
                <div class="card shadow border-0 rounded-4 overflow-hidden">
                    <div class="card-header bg-dark text-white py-3 text-center">
                        <h6 class="mb-0 fw-bold text-uppercase ls-1">Genel Yapılandırma</h6>
                    </div>
                    <div class="card-body p-4 p-md-5">
                        <form method="POST" action="/ayarlar" class="needs-validation" novalidate>
                            @csrf
                            <div class="row g-5">
                                <div class="col-md-6 position-relative">
                                    <h6 class="text-secondary fw-bold border-bottom pb-2 mb-4">🇹🇷 TL & Üretim Giderleri</h6>
                                    
                                    <div class="row g-3">
                                        <div class="col-6">
                                            <label class="form-label fw-semibold small text-muted">Altın Fiyatı (₺)</label>
                                            <div class="input-group input-group-sm">
                                                <span class="input-group-text bg-light border-end-0"><i class="fa-solid"></i></span>
                                                <input type="number" step="0.01" name="altin_fiyat" value="{{ $ayar->altin_fiyat }}" class="form-control border-start-0 ps-0 fw-bold text-dark">
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <label class="form-label fw-semibold small text-muted">Ayar</label>
                                            <input type="number" name="ayar" value="{{ $ayar->ayar }}" class="form-control form-control-sm fw-bold text-center">
                                        </div>
                                    </div>

                                    <div class="mt-3">
                                        <label class="form-label fw-semibold small text-muted">İşçilik (₺)</label>
                                        <input type="number" step="0.01" name="iscilik" value="{{ $ayar->iscilik }}" class="form-control form-control-sm">
                                    </div>

                                    <div class="mt-3">
                                        <label class="form-label fw-semibold small text-muted">Yurtiçi Kargo (₺)</label>
                                        <input type="number" step="0.01" name="kargo" value="{{ $ayar->kargo }}" class="form-control form-control-sm">
                                    </div>

                                    <div class="row g-3 mt-1">
                                        <div class="col-6">
                                            <label class="form-label fw-semibold small text-muted">Kutu + Poşet (₺)</label>
                                            <input type="number" step="0.01" name="kutu" value="{{ $ayar->kutu }}" class="form-control form-control-sm">
                                        </div>
                                        <div class="col-6">
                                            <label class="form-label fw-semibold small text-muted">Reklam Gideri (₺)</label>
                                            <input type="number" step="0.01" name="reklam" value="{{ $ayar->reklam }}" class="form-control form-control-sm">
                                        </div>
                                    </div>
                                    
                                    <div class="mt-3">
                                        <label class="form-label fw-semibold small text-muted">KDV Oranı (%)</label>
                                        <div class="input-group input-group-sm">
                                            <input type="number" step="0.01" name="kdv" value="{{ $ayar->kdv }}" class="form-control">
                                            <span class="input-group-text">%</span>
                                        </div>
                                    </div>

                                    {{-- Dikey Çizgi (Mobilde gizli) --}}
                                    <div class="d-none d-md-block position-absolute top-0 end-0 h-100 border-end" style="margin-right: -1.5rem;"></div>
                                </div>

                                <div class="col-md-6 ps-md-5">
                                    <h6 class="text-secondary fw-bold border-bottom pb-2 mb-4">🌍 Döviz & İhracat</h6>

                                    <div class="row g-3">
                                        <div class="col-6">
                                            <label class="form-label fw-semibold small text-muted">Dolar Kuru (₺)</label>
                                            <input type="number" step="0.0001" name="dolar_kuru" value="{{ $ayar->dolar_kuru }}" class="form-control form-control-sm fw-bold">
                                        </div>
                                        <div class="col-6">
                                            <label class="form-label fw-semibold small text-muted">Altın ($)</label>
                                            <input type="number" step="0.01" name="altin_usd" value="{{ $ayar->altin_usd }}" class="form-control form-control-sm fw-bold">
                                        </div>
                                    </div>

                                    <div class="mt-3">
                                        <label class="form-label fw-semibold small text-muted">Yurtdışı Kargo ($ veya ₺)</label>
                                        <input type="number" step="0.01" name="kargo_yurtdisi" value="{{ $ayar->kargo_yurtdisi }}" class="form-control form-control-sm">
                                    </div>

                                    <div class="card bg-light border-0 mt-4">
                                        <div class="card-body py-3 px-3">
                                            <h6 class="small fw-bold text-dark mb-3"><i class="fa-brands fa-etsy me-1"></i> Etsy Ayarları</h6>
                                            <div class="mb-2">
                                                <label class="form-label x-small text-muted mb-1">Shipping Cost ($)</label>
                                                <input type="number" step="0.01" name="etsy_ship_cost" value="{{ $ayar->etsy_ship_cost }}" class="form-control form-control-sm bg-white">
                                            </div>
                                            <div class="mb-0">
                                                <label class="form-label x-small text-muted mb-1">USA Tax Rate (%)</label>
                                                <input type="number" step="0.0001" name="etsy_usa_tax_rate" value="{{ $ayar->etsy_usa_tax_rate }}" class="form-control form-control-sm bg-white">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <hr class="my-4 text-muted">
                            <button type="submit" class="btn btn-dark w-100 py-3 fw-bold shadow-sm rounded-3">
                                <i class="fa-solid fa-check-circle me-2"></i> DEĞİŞİKLİKLERİ KAYDET
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            {{-- TAB 2: PAZARYERİ AYARLARI --}}
            <div class="tab-pane fade" id="pazar" role="tabpanel">
                
                {{-- EKLEME KARTI --}}
                <div class="card border-0 shadow-sm mb-4 rounded-4" style="background: linear-gradient(to right, #f8f9fa, #e9ecef);">
                    <div class="card-body p-4">
                        <div class="row align-items-center">
                            <div class="col-md-3 mb-2 mb-md-0">
                                <h6 class="fw-bold text-dark mb-0"><i class="fa-solid fa-plus-circle me-2 text-success"></i>Yeni Pazar Ekle</h6>
                                <small class="text-muted">Platform adı ve komisyonu</small>
                            </div>
                            <div class="col-md-9">
                                <form action="{{ route('pazaryeri.store') }}" method="POST" class="row g-2 align-items-end">
                                    @csrf
                                    <div class="col-md-5">
                                        <input type="text" name="Ad" class="form-control border-0 shadow-sm" placeholder="Pazaryeri Adı (Ör: Amazon)" required style="height: 45px;">
                                    </div>
                                    <div class="col-md-4">
                                        <div class="input-group shadow-sm">
                                            <input type="number" step="0.01" min="0" max="100" name="KomisyonOrani" class="form-control border-0" placeholder="Komisyon" required style="height: 45px;">
                                            <span class="input-group-text border-0 bg-white">%</span>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <button class="btn btn-success w-100 fw-semibold shadow-sm" style="height: 45px;">EKLE</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- LİSTELEME KARTI --}}
                <div class="card shadow border-0 rounded-4 overflow-hidden">
                    <div class="card-header bg-white py-3 border-bottom">
                        <h6 class="mb-0 fw-bold text-secondary">📋 Mevcut Pazaryerleri</h6>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light small text-uppercase text-muted">
                                <tr>
                                    <th class="ps-4" style="width: 60px;">ID</th>
                                    <th>Platform</th>
                                    <th style="width: 220px;">Komisyon Oranı</th>
                                    <th style="width: 100px;" class="text-end pe-4">İşlem</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white">
                                @foreach($pazaryerleri as $p)
                                    @php
                                        $isEtsy = strtolower($p->Ad) === 'etsy';
                                        $isSite = strtolower($p->Ad) === 'site';
                                    @endphp
                                    <tr>
                                        <td class="ps-4 fw-bold text-muted small">#{{ $p->id }}</td>
                                        <td>
                                            <form id="form-update-{{$p->id}}" action="{{ route('pazaryeri.update', $p->id) }}" method="POST">
                                                @csrf
                                                <div class="d-flex align-items-center">
                                                    <input type="text" name="Ad" class="form-control form-control-sm border-0 bg-transparent fw-bold text-dark px-0" value="{{ $p->Ad }}" style="max-width: 180px; font-size:1rem;">
                                                    
                                                    @if($isEtsy)
                                                        <span class="badge rounded-pill bg-warning text-dark ms-2" style="font-size: 0.7rem;">USD / İhracat</span>
                                                    @elseif($isSite)
                                                        <span class="badge rounded-pill bg-success ms-2" style="font-size: 0.7rem;">Web Sitemiz</span>
                                                    @endif
                                                </div>
                                        </td>
                                        <td>
                                            <div class="input-group input-group-sm" style="max-width: 160px;">
                                                <input type="number" step="0.01" min="0" max="100" name="KomisyonOrani" class="form-control fw-bold text-center border-secondary border-opacity-25" value="{{ $p->KomisyonOrani * 100 }}">
                                                <span class="input-group-text bg-light border-secondary border-opacity-25">%</span>
                                                <button class="btn btn-outline-dark" type="submit" title="Güncelle">
                                                    <i class="fa-solid fa-rotate"></i>
                                                </button>
                                            </div>
                                            </form>
                                        </td>
                                        <td class="text-end pe-4">
                                            @if(!$isSite)
                                                <form action="{{ route('pazaryeri.destroy', $p->id) }}" method="POST" class="d-inline">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button class="btn btn-link text-danger p-0 text-decoration-none" onclick="return confirm('Silmek istediğinize emin misiniz?')" title="Sil">
                                                        <i class="fa-regular fa-trash-can fa-lg"></i>
                                                    </button>
                                                </form>
                                            @else
                                                <i class="fa-solid fa-lock text-muted opacity-50"></i>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>

{{-- EK CSS --}}
<style>
    .nav-pills .nav-link {
        color: #6c757d;
        transition: all 0.3s ease;
    }
    .nav-pills .nav-link.active {
        background-color: #212529 !important; /* Dark butonu */
        color: #fff !important;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    .form-control:focus {
        box-shadow: 0 0 0 0.25rem rgba(33, 37, 41, 0.15);
        border-color: #212529;
    }
    .x-small {
        font-size: 0.75rem;
    }
    .ls-1 {
        letter-spacing: 1px;
    }
</style>

@endsection