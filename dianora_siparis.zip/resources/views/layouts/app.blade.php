<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Dianora Control Panel')</title>

    {{-- Font: Inter (Modern & Okunaklı) --}}
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    {{-- Bootstrap & Icons --}}
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">

    <style>
        :root {
            --bg-body: #f2f2f2;       /* Çok açık gri (Gözü almaz) */
            --header-bg: #000000;     /* Tam Siyah */
            --active-item: #ffffff;   /* Aktif menü arka planı */
            --text-muted: #9ca3af;    /* Soluk gri metinler */
        }

        body {
            background-color: var(--bg-body);
            font-family: 'Inter', sans-serif;
            color: #111; /* Koyu Gri/Siyah yazı */
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* --- 1. BİLGİ ŞERİDİ (Ticker) --- */
        .info-ticker {
            background-color: #1a1a1a; /* Siyahın bir ton açığı */
            color: #ccc;
            font-size: 0.75rem;
            padding: 5px 0;
            border-bottom: 1px solid #333;
            font-family: monospace; /* Borsa havası */
        }
        .info-val { color: #fff; font-weight: 700; letter-spacing: 1px; }

        /* --- 2. NAVBAR (MENÜ) --- */
        .navbar {
            background-color: var(--header-bg);
            padding: 0.8rem 0;
            /* Altına ince bir gri çizgi ekleyerek ayrım yapıyoruz */
            border-bottom: 1px solid #333; 
        }

        /* Logo Ayarları */
        .navbar-brand img {
            height: 36px;
            /* ÖNEMLİ: Logon siyahsa, siyah zemin üzerinde görünmez. 
               Bu filtre logoyu beyaza çevirir. Logon zaten beyazsa bu satırı sil. */
            filter: brightness(0) invert(1); 
            transition: opacity 0.3s;
        }
        .navbar-brand:hover img { opacity: 0.8; }

        /* Linkler */
        .nav-link {
            color: #999 !important; /* Pasif linkler gri */
            font-weight: 500;
            font-size: 0.9rem;
            margin: 0 5px;
            padding: 8px 18px !important;
            border-radius: 50px; /* Hap şeklinde butonlar */
            transition: all 0.3s ease;
        }

        /* Hover Durumu */
        .nav-link:hover {
            color: #fff !important;
            background-color: rgba(255,255,255,0.1);
        }

        /* Aktif (Seçili) Durum */
        .nav-link.active {
            background-color: #fff; /* Beyaz arka plan */
            color: #000 !important; /* Siyah yazı */
            font-weight: 600;
            box-shadow: 0 0 15px rgba(255,255,255,0.15); /* Hafif parlama */
        }
        
        /* Aktif olmayan ikonlar soluk kalsın */
        .nav-link i { margin-right: 6px; font-size: 1rem; }
        .nav-link.active i { color: #000; } /* Aktifse ikon siyah */

        /* Mobil Menü */
        .navbar-toggler { border: 1px solid #333; }
        .navbar-toggler-icon { filter: invert(1); } /* İkonu beyaz yap */

        /* --- CONTENT --- */
        main { flex: 1; }

        /* --- FOOTER --- */
        footer {
            background: #fff;
            border-top: 1px solid #e5e5e5;
            padding: 30px 0;
            font-size: 0.85rem;
            color: #666;
        }
    </style>

    @yield('head')
</head>
<body>

    {{-- 1. EN ÜST BİLGİ ŞERİDİ --}}
    @php
        $altin = null;
        $path = base_path('altin.json');
        if (file_exists($path)) $altin = json_decode(file_get_contents($path), true);
    @endphp

    @if($altin)
        <div class="info-ticker">
            <div class="container d-flex justify-content-between align-items-center">
                <div class="d-none d-md-block text-secondary">
                    Bir MörfSoft projesidir. &nbsp;|&nbsp; Geliştirici: <a href="https://morfingen.info" target="_blank" class="text-secondary text-decoration-underline">MörfSoft</a>
                </div>
                <div class="d-flex align-items-center gap-3 ms-auto ms-md-0">
                    <span class="text-secondary"><i class="fa-regular fa-gem me-1"></i>HAS ALTIN:</span>
                    <span>ALIŞ: <span class="info-val">{{ number_format($altin['alis'], 2, ',', '.') }}</span></span>
                    <span class="text-secondary">/</span>
                    <span>SATIŞ: <span class="info-val">{{ number_format($altin['satis'], 2, ',', '.') }}</span></span>
                </div>
            </div>
        </div>
    @endif

    {{-- 2. NAVBAR --}}
    <nav class="navbar navbar-expand-lg sticky-top">
        <div class="container">
            
            {{-- LOGO --}}
            <a class="navbar-brand" href="{{ url('/siparisler') }}">
                <img src="/images/logo.png" alt="Dianora">
            </a>

            {{-- MOBİL BUTON --}}
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
                <span class="navbar-toggler-icon"></span>
            </button>

            {{-- MENÜ --}}
            <div class="collapse navbar-collapse" id="mainNav">
                <ul class="navbar-nav ms-auto mt-3 mt-lg-0">
                    
                    <li class="nav-item">
                        <a href="{{ url('/siparisler') }}" class="nav-link {{ request()->is('siparisler*') ? 'active' : '' }}">
                            <i class="fa-solid fa-box"></i> Siparişler
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="{{ url('/istatistikler') }}" class="nav-link {{ request()->is('istatistikler*') ? 'active' : '' }}">
                            <i class="fa-solid fa-chart-simple"></i> İstatistikler
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="{{ url('/fiyat') }}" class="nav-link {{ request()->is('fiyat*') ? 'active' : '' }}">
                            <i class="fa-solid fa-calculator"></i> Fiyat Sihirbazı
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="{{ url('/ayarlar') }}" class="nav-link {{ request()->is('ayarlar*') ? 'active' : '' }}">
                            <i class="fa-solid fa-sliders"></i> Ayarlar
                        </a>
                    </li>

                    <li class="nav-item">
                        <a href="{{ url('/kategoriler') }}" class="nav-link {{ request()->is('kategoriler*') ? 'active' : '' }}">
                            <i class="fa-solid fa-percent"></i> Kâr Oranları
                        </a>
                    </li>

                </ul>
            </div>
        </div>
    </nav>

    {{-- 3. İÇERİK --}}
    <main>
        @yield('content')
    </main>

    {{-- 4. FOOTER --}}
    <footer>
        <div class="container text-center d-flex flex-column align-items-center gap-2">
            
            {{-- Footer Logo (Gri Tonlamalı) --}}
            <img src="/images/logo.png" alt="Logo" style="height: 18px; opacity: 0.3; filter: grayscale(100%);">
            
            <div class="small text-muted">
                &copy; {{ date('Y') }} Dianora Piercing & Jewelry
            </div>
            <div class="small text-muted">
                 Tüm hakları saklıdır.
        </div>
    </footer>

    {{-- Scriptler --}}
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    @yield('scripts')
</body>
</html>