@extends('layouts.app')

@section('title', 'Fiyat Sihirbazı')

@section('content')
<div class="container-fluid py-4 bg-light" style="min-height: 100vh; background-color: #f8f9fa !important;">
    <div class="px-3 px-xxl-5"> 

        {{-- ÜST BAŞLIK ALANI --}}
        <div class="row align-items-center mb-4">
            <div class="col-md-6">
                <h3 class="fw-bold text-dark mb-1 ls-tight">
                    <i class="fa-solid fa-wand-magic-sparkles text-primary me-2"></i>Fiyat Sihirbazı
                </h3>
                <p class="text-muted mb-0 small">Kuyumcu matematiği ile hassas hesaplama.</p>
            </div>
            <div class="col-md-6 text-md-end mt-3 mt-md-0">
                <div class="d-inline-flex gap-3">
                    <div class="d-flex align-items-center bg-white px-3 py-2 rounded-4 shadow-sm border border-light">
                        {{-- İkon Ortalaması İçin: d-flex align-items-center justify-content-center --}}
                        <div class="icon-box bg-warning bg-opacity-10 text-warning rounded-circle me-2 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px; font-size: 0.9rem;">
                            <i class="fa-solid fa-coins"></i>
                        </div>
                        <div class="text-start">
                            <small class="text-muted d-block text-uppercase x-small fw-bold" style="font-size: 0.65rem;">Has Altın</small>
                            <span class="fw-bold text-dark" id="lblAltin">- ₺</span>
                        </div>
                    </div>
                    <div class="d-flex align-items-center bg-white px-3 py-2 rounded-4 shadow-sm border border-light">
                        {{-- İkon Ortalaması İçin: d-flex align-items-center justify-content-center --}}
                        <div class="icon-box bg-success bg-opacity-10 text-success rounded-circle me-2 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px; font-size: 0.9rem;">
                            <i class="fa-solid fa-dollar-sign"></i>
                        </div>
                        <div class="text-start">
                            <small class="text-muted d-block text-uppercase x-small fw-bold" style="font-size: 0.65rem;">Dolar Kuru</small>
                            <span class="fw-bold text-dark" id="lblDolar">- ₺</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4"> 
            
            {{-- SOL KOLON: PARAMETRELER (Siyah Header) --}}
            <div class="col-lg-4 col-xl-3">
                <div class="card border-0 shadow-lg rounded-4 overflow-hidden sticky-top" style="top: 20px; z-index: 100;">
                    <div class="card-header bg-dark text-white p-3 border-0">
                        <h6 class="fw-bold mb-0 d-flex align-items-center">
                            <i class="fa-solid fa-sliders me-2 text-white-50"></i>Parametreler
                        </h6>
                    </div>
                    <div class="card-body p-4 bg-white">
                        <form id="calcForm" onsubmit="return false;">
                            @csrf
                            
                            {{-- Ürün Kodu --}}
                            <div class="mb-3">
                                <label class="form-label fw-bold text-secondary x-small text-uppercase ls-1 mb-1">Ürün Kodu</label>
                                <div class="input-group shadow-sm rounded-3 overflow-hidden">
                                    <span class="input-group-text bg-white border-0 ps-3 text-primary"><i class="fa-solid fa-barcode"></i></span>
                                    <input type="text" id="urunKodu" class="form-control bg-white border-0 fw-bold text-dark shadow-none" placeholder="Örn: CH001" autocomplete="off">
                                    <button class="btn btn-primary px-3" type="button" id="btnGetir">
                                        <i class="fa-solid fa-search"></i>
                                    </button>
                                </div>
                                <div class="form-text mt-1 ps-1" id="urunMsg" style="min-height: 18px; font-size: 0.75rem;"></div>
                            </div>

                            {{-- Kategori --}}
                            <div class="mb-3">
                                <label class="form-label fw-bold text-secondary x-small text-uppercase ls-1 mb-1">Kategori</label>
                                <div class="input-group shadow-sm rounded-3 overflow-hidden">
                                    <span class="input-group-text bg-white border-0 ps-3 text-info"><i class="fa-solid fa-layer-group"></i></span>
                                    <select id="kategoriId" class="form-select bg-white border-0 fw-bold text-dark shadow-none" style="cursor: pointer;">
                                        <option value="" data-kar="0">Seçiniz...</option>
                                        @foreach($kategoriler as $kat)
                                            <option value="{{ $kat->Id }}" data-kar="{{ $kat->KarOrani }}">
                                                {{ $kat->KategoriAdi }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                            {{-- Gram --}}
                            <div class="mb-4">
                                <label class="form-label fw-bold text-secondary x-small text-uppercase ls-1 mb-1">Has Gram</label>
                                <div class="input-group shadow-sm rounded-3 overflow-hidden">
                                    <span class="input-group-text bg-white border-0 ps-3 text-warning"><i class="fa-solid fa-scale-balanced"></i></span>
                                    <input type="number" step="0.01" id="gram" class="form-control bg-white border-0 fw-bold fs-5 text-dark shadow-none" placeholder="0.00">
                                    <span class="input-group-text bg-white border-0 text-muted small">gr</span>
                                </div>
                            </div>

                            {{-- Kâr Oranı --}}
                            <div class="p-3 bg-light bg-opacity-50 rounded-3 border border-dashed mb-4">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <label class="form-label fw-bold text-dark mb-0 x-small text-uppercase">Net Kâr</label>
                                    <span class="badge bg-white text-primary border shadow-sm" id="lblKarOrani">%0</span>
                                </div>
                                <input type="range" class="form-range custom-range" min="0" max="200" step="5" id="rangeKar" value="0" disabled>
                            </div>

                            <button type="button" class="btn btn-dark w-100 py-3 rounded-3 fw-bold shadow-lg btn-hover-effect" onclick="hesapla()">
                                HESAPLA <i class="fa-solid fa-arrow-right ms-2"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            {{-- SAĞ KOLON: SONUÇLAR --}}
            <div class="col-lg-8 col-xl-9">
                
                {{-- Yükleniyor --}}
                <div id="loadingState" class="d-none h-100 d-flex flex-column justify-content-center align-items-center py-5" style="min-height: 300px;">
                    <div class="spinner-border text-primary mb-4" style="width: 3rem; height: 3rem;" role="status"></div>
                    <h5 class="text-muted fw-normal">Hesaplamalar yapılıyor...</h5>
                </div>

                {{-- Boş Durum --}}
                <div id="emptyState" class="text-center py-5 bg-white rounded-4 shadow-sm border border-dashed h-100 d-flex flex-column justify-content-center align-items-center" style="min-height: 300px;">
                    <div class="bg-light p-4 rounded-circle mb-4">
                        <i class="fa-solid fa-calculator fa-3x text-secondary opacity-50"></i>
                    </div>
                    <h3 class="text-dark fw-bold mb-2">Hazır</h3>
                    <p class="text-muted small">Lütfen soldan parametreleri giriniz.</p>
                </div>

                {{-- Sonuç Grid --}}
                <div id="resultState" class="d-none">
                    <div class="row g-4" id="resultsContainer">
                        <!-- JavaScript ile doldurulacak -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- CUSTOM CSS --}}
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap');
    
    body { font-family: 'Inter', sans-serif; }
    .ls-tight { letter-spacing: -0.5px; }
    .ls-1 { letter-spacing: 1px; }
    .x-small { font-size: 0.75rem; }

    /* Form Input İyileştirmeleri */
    .input-group:focus-within {
        box-shadow: 0 0 0 2px rgba(13, 110, 253, 0.25) !important;
    }
    
    /* Range Slider */
    .custom-range::-webkit-slider-thumb {
        background: #0d6efd;
        width: 16px; height: 16px;
        margin-top: -6px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }
    .custom-range::-webkit-slider-runnable-track {
        height: 4px; background: #e9ecef; border-radius: 2px;
    }

    /* Buton Efekti */
    .btn-hover-effect { transition: all 0.2s ease; }
    .btn-hover-effect:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,0,0,0.15) !important; }

    /* --- SONUÇ KARTLARI --- */
    .result-card {
        background: #fff;
        border-radius: 1rem;
        position: relative;
        transition: all 0.3s ease;
        border: 1px solid rgba(0,0,0,0.04);
        overflow: hidden;
    }
    .result-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 30px rgba(0,0,0,0.08);
        border-color: transparent;
    }

    /* Renkli Üst Çizgi */
    .card-top-line {
        height: 4px;
        width: 100%;
        position: absolute;
        top: 0; left: 0;
    }

    /* Kart İçeriği */
    .card-content { padding: 1.5rem; }

    /* Fiyat Alanı */
    .price-area {
        margin: 0.5rem 0 1rem 0;
        text-align: left;
    }
    .price-label {
        font-size: 0.7rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: #adb5bd;
        font-weight: 700;
        margin-bottom: 0.2rem;
    }
    .main-price {
        font-size: 2rem;
        font-weight: 800;
        line-height: 1;
        letter-spacing: -0.5px;
    }
    
    /* Alt Bilgi Alanı */
    .card-footer-info {
        margin-top: auto;
        padding-top: 1rem;
        border-top: 1px dashed #f1f3f5;
        display: flex;
        justify-content: space-between;
        align-items: flex-start; /* İki satırlı metinler için hizalama */
    }

    /* Detay Overlay (Hover) */
    .details-overlay {
        position: absolute;
        top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(255,255,255,0.97);
        backdrop-filter: blur(5px);
        padding: 1.5rem;
        display: flex;
        flex-direction: column;
        opacity: 0;
        visibility: hidden;
        transition: all 0.25s ease;
        z-index: 10;
    }
    .result-card:hover .details-overlay {
        opacity: 1;
        visibility: visible;
    }

    .detail-item {
        display: flex;
        justify-content: space-between;
        margin-bottom: 0.5rem;
        font-size: 0.85rem;
        color: #6c757d;
    }
    .detail-item span:last-child {
        font-weight: 600;
        color: #212529;
    }
</style>

{{-- JAVASCRIPT --}}
<script>
    // Değişkenler
    const inpUrunKodu = document.getElementById('urunKodu');
    const inpGram = document.getElementById('gram');
    const selKategori = document.getElementById('kategoriId');
    const rangeKar = document.getElementById('rangeKar');
    const lblKar = document.getElementById('lblKarOrani');
    
    const loadingState = document.getElementById('loadingState');
    const emptyState = document.getElementById('emptyState');
    const resultState = document.getElementById('resultState');
    const resultsContainer = document.getElementById('resultsContainer');
    const csrfToken = document.querySelector('input[name="_token"]').value;
    const badgeConfig = @json($badges ?? []);

    // Event Listeners
    inpUrunKodu.addEventListener('keypress', function (e) { if (e.key === 'Enter') fetchUrun(); });
    document.getElementById('btnGetir').addEventListener('click', fetchUrun);
    
    selKategori.addEventListener('change', function() {
        const opt = this.options[this.selectedIndex];
        const kar = opt.getAttribute('data-kar') || 0;
        rangeKar.value = kar;
        lblKar.innerText = '%' + kar;
        if(inpGram.value > 0) hesapla();
    });

    // 1. ÜRÜN GETİR
    async function fetchUrun() {
        const kod = inpUrunKodu.value.trim();
        const msgDiv = document.getElementById('urunMsg');
        if(!kod) return;
        
        msgDiv.innerHTML = '<span class="text-primary"><i class="fa-solid fa-spinner fa-spin"></i> Aranıyor...</span>';
        
        try {
            const res = await fetch("{{ route('fiyat.urunGetir') }}?urun_kodu=" + kod);
            const data = await res.json();
            
            if(data.status) {
                inpGram.value = data.urun.Gram;
                selKategori.value = data.urun.KategoriId;
                selKategori.dispatchEvent(new Event('change'));
                msgDiv.innerHTML = '<span class="text-success fw-bold"><i class="fa-solid fa-check"></i> Bulundu.</span>';
                hesapla();
            } else {
                msgDiv.innerHTML = '<span class="text-danger fw-bold"><i class="fa-solid fa-times"></i> Yok.</span>';
                inpGram.value = '';
            }
        } catch (err) { 
            console.error(err);
            msgDiv.innerHTML = '<span class="text-danger">Hata.</span>'; 
        }
    }

    // 2. HESAPLA
    async function hesapla() {
        const gram = parseFloat(inpGram.value);
        const katId = selKategori.value;
        
        if(!gram || gram <= 0) {
            alert("Lütfen geçerli bir gram değeri giriniz.");
            return;
        }

        emptyState.classList.add('d-none');
        resultState.classList.add('d-none');
        loadingState.classList.remove('d-none');

        try {
            const fd = new FormData();
            fd.append('_token', csrfToken);
            fd.append('gram', gram);
            fd.append('kategori_id', katId);

            const res = await fetch("{{ route('fiyat.hesapla') }}", { method: 'POST', body: fd });
            const data = await res.json();

            if(data.status) {
                // Gelen veriyi JS tarafında sıralıyoruz (TL -> USD -> ELDEN)
                // Bu sayede Etsy kartları her zaman yan yana gelir.
                let sortedResults = data.sonuclar.sort((a, b) => {
                    // Sıralama önceliği: TL (tur!='USD' ve id!=99) -> USD (tur=='USD') -> Elden (id==99)
                    const getRank = (item) => {
                        if (item.id == 99) return 3; // Elden en son
                        if (item.tur === 'USD') return 2; // Dolar ortada
                        return 1; // TL en başa
                    };
                    return getRank(a) - getRank(b);
                });

                renderResults(sortedResults);
                
                if(data.meta) {
                    document.getElementById('lblAltin').innerText = data.meta.altin_tl + ' ₺';
                    document.getElementById('lblDolar').innerText = data.meta.dolar + ' ₺';
                }
            } else {
                alert(data.message);
                emptyState.classList.remove('d-none');
            }
        } catch (err) {
            console.error(err);
            alert('Bir hata oluştu.');
            emptyState.classList.remove('d-none');
        } finally {
            if(loadingState.classList.contains('d-none')) return;
            loadingState.classList.add('d-none');
            resultState.classList.remove('d-none');
        }
    }

    // 3. SONUÇLARI ÇİZ
    function renderResults(sonuclar) {
        let html = '';
        sonuclar.forEach(item => {
            const cfg = badgeConfig[item.id];
            if(!cfg) return;

            const sembol = item.tur === 'USD' ? '$' : '₺';
            
            // İKON MANTIĞI (Görsel yoksa FontAwesome)
            let logoHtml = '';
            if(cfg.image) {
                logoHtml = `<img src="${cfg.image}" style="height: 24px; width: auto; object-fit: contain;">`;
            } else {
                let iconPrefix = 'fa-solid';
                if(cfg.icon.includes('etsy') || cfg.icon.includes('n11') || cfg.icon.includes('instagram')) {
                    iconPrefix = 'fa-brands';
                }
                logoHtml = `<i class="${iconPrefix} ${cfg.icon} fs-4" style="color:${cfg.bg}"></i>`;
            }

            // Etsy Başlık Düzenlemesi
            let displayTitle = item.ad || cfg.text;
            if(displayTitle === 'Etsy (USA)') displayTitle = 'Etsy (Amerika/USA)';
            if(displayTitle === 'Etsy (Diğer)') displayTitle = 'Etsy (EU/Diğer)';

            // Liste Fiyatı (%10) Gösterimi
            let oldPriceHtml = '';
            if(item.buffer_fiyati) {
                oldPriceHtml = `
                <div class="mb-2">
                    <div class="d-inline-flex align-items-center border rounded px-2 py-1 bg-light bg-opacity-75" title="Pazaryerine Girilecek Liste Fiyatı">
                        <span class="badge bg-dark bg-opacity-10 text-dark me-2 px-1" style="font-size: 0.65rem;">%10</span>
                        <span class="fw-bold text-dark" style="font-size: 0.9rem;">${item.buffer_fiyati} ${sembol}</span>
                    </div>
                </div>`;
            }
            
            // Ekstra Notlar ve TL Karşılıkları (FONT BÜYÜTÜLDÜ)
            let extraNote = '';
            let costNote = '';
            let netNote = '';

            if(item.id == 99 && item.ekstra_fiyat) {
                extraNote = `<div class="mt-1"><span class="badge bg-success bg-opacity-10 text-success px-2 py-1">Nakit: ${item.ekstra_fiyat}</span></div>`;
            } else if (item.tur === 'USD') {
                // Kur Bilgisi
                extraNote = `<div class="mt-1 text-muted x-small">(${item.kur_karsiligi})</div>`;
                
                // TL Karşılıklarını Ekle (Varsa) - Font büyütüldü (0.75rem)
                if(item.maliyet_tl) {
                    costNote = `<div class="text-muted fw-light x-small mt-1" style="font-size: 0.75rem;">≈ ${item.maliyet_tl} ₺</div>`;
                }
                if(item.net_kar_tl) {
                    netNote = `<div class="text-success fw-light x-small mt-1" style="font-size: 0.75rem; opacity: 0.85;">≈ ${item.net_kar_tl} ₺</div>`;
                }
            }

            // Kargo Satırı
            let kargoHtml = '';
            if(item.detay_kargo && item.detay_kargo !== '0.00') {
                kargoHtml = `
                <div class="detail-item">
                    <span><i class="fa-solid fa-truck-fast me-2 text-info"></i>Kargo</span>
                    <span class="text-danger">${item.detay_kargo} ${sembol}</span>
                </div>`;
            }

            html += `
            <div class="col-sm-6 col-md-6 col-xl-4">
                <div class="result-card h-100 shadow-sm">
                    <div class="card-top-line" style="background-color: ${cfg.bg}"></div>
                    
                    <div class="card-content d-flex flex-column h-100">
                        <!-- HEADER -->
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div class="d-flex align-items-center gap-2">
                                <div class="rounded-circle bg-light d-flex align-items-center justify-content-center border" style="width:40px; height:40px;">
                                    ${logoHtml}
                                </div>
                                <div>
                                    <h6 class="fw-bold text-dark mb-0" style="font-size: 0.95rem;">${displayTitle}</h6>
                                    <span class="text-muted x-small text-uppercase fw-bold" style="font-size: 0.65rem;">${item.tur} Bazlı</span>
                                </div>
                            </div>
                        </div>

                        <!-- PRICE BLOCK -->
                        <div class="price-area">
                            ${oldPriceHtml}
                            <div class="price-label mt-2">Satış Fiyatı</div>
                            <div class="main-price" style="color: ${cfg.bg}">${item.satis_fiyati} <span class="fs-5 fw-light text-muted">${sembol}</span></div>
                            ${extraNote}
                        </div>

                        <!-- FOOTER INFO -->
                        <div class="card-footer-info">
                            <div>
                                <div class="text-muted x-small fw-bold text-uppercase" style="font-size: 0.65rem;">Maliyet</div>
                                <div class="fw-bold text-secondary small">${item.detay_maliyet} ${sembol}</div>
                                ${costNote}
                            </div>
                            <div class="text-end">
                                <div class="text-muted x-small fw-bold text-uppercase" style="font-size: 0.65rem;">Net Kazanç</div>
                                <div class="fw-bold fs-6 text-success">${item.net_kar}</div>
                                ${netNote}
                            </div>
                        </div>
                    </div>

                    <!-- HOVER DETAILS -->
                    <div class="details-overlay">
                        <h6 class="fw-bold text-dark mb-3 pb-2 border-bottom small">
                            <i class="fa-solid fa-chart-pie me-2 text-primary"></i>Satış Fiyatı Dağılımı
                        </h6>
                        
                        <div class="detail-item">
                            <span><i class="fa-regular fa-gem me-2 text-warning"></i>Has Altın</span>
                            <span>${item.detay_altin} ${sembol}</span>
                        </div>
                        <div class="detail-item">
                            <span><i class="fa-solid fa-wrench me-2 text-secondary"></i>İşçilik & Gider</span>
                            <span>${item.detay_gider} ${sembol}</span>
                        </div>
                        <div class="detail-item">
                            <span><i class="fa-solid fa-percent me-2 text-danger"></i>Komisyon</span>
                            <span class="text-danger">${item.detay_komisyon} ${sembol}</span>
                        </div>
                        <div class="detail-item">
                            <span><i class="fa-solid fa-building-columns me-2 text-danger"></i>KDV / Vergi</span>
                            <span class="text-danger">${item.detay_vergi} ${sembol}</span>
                        </div>
                        ${kargoHtml}
                        
                        <div class="mt-auto pt-2 border-top d-flex justify-content-between align-items-center">
                            <span class="fw-bold text-dark small">NET KÂR</span>
                            <span class="fw-bold fs-5 text-success bg-success bg-opacity-10 px-2 rounded">${item.net_kar}</span>
                        </div>
                        <div class="text-center mt-2 pt-1 border-top border-light">
                           <small class="text-muted x-small" style="font-size:0.65rem;">Toplam = Satış Fiyatı</small>
                        </div>
                    </div>

                </div>
            </div>`;
        });
        resultsContainer.innerHTML = html;
    }
</script>
@endsection