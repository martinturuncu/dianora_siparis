@extends('layouts.app')

@section('title', 'Manuel Sipariş Ekle')

@section('content')
<div class="container py-5" style="max-width: 850px;">

    {{-- ÜST BAŞLIK --}}
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4 gap-3">
        <div>
            <h3 class="fw-bold text-dark mb-0">
                <i class="fa-solid fa-file-pen text-primary me-2"></i>Manuel Sipariş Oluştur
            </h3>
            <p class="text-muted small mb-0">Sistem dışından gelen satışları buradan kaydedebilirsiniz.</p>
        </div>
        <a href="{{ route('siparisler.index') }}" class="btn btn-light border shadow-sm fw-semibold text-secondary">
            <i class="fa-solid fa-arrow-left me-2"></i>Listeye Dön
        </a>
    </div>

    {{-- BİLDİRİMLER --}}
    @if(session('hata'))
        <div class="alert alert-danger shadow-sm border-0 border-start border-danger border-4 rounded-3">
            <i class="fa-solid fa-circle-exclamation me-2"></i>{{ session('hata') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="alert alert-warning shadow-sm border-0 border-start border-warning border-4 rounded-3">
            <h6 class="fw-bold text-dark"><i class="fa-solid fa-triangle-exclamation me-2"></i>Lütfen bilgileri kontrol edin:</h6>
            <ul class="mb-0 ps-3 small text-dark">
                @foreach ($errors->all() as $hata)
                    <li>{{ $hata }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    {{-- FORM KARTI --}}
    <div class="card border-0 shadow-lg rounded-4 overflow-hidden">
        <div class="card-header bg-white border-bottom p-4">
            <h6 class="fw-bold text-secondary text-uppercase ls-1 mb-0">Sipariş Detayları</h6>
        </div>
        
        <div class="card-body p-4 p-md-5 bg-light bg-opacity-25">
            <form action="{{ route('siparisler.manuel.store') }}" method="POST" class="needs-validation" novalidate>
                @csrf

                {{-- BÖLÜM 1: MÜŞTERİ & PLATFORM --}}
                <div class="row g-4 mb-4">
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-dark small">Müşteri Adı Soyadı</label>
                        {{-- ÖZEL CSS SINIFI: merged-group --}}
                        <div class="input-group merged-group">
                            <span class="input-group-text"><i class="fa-solid fa-user text-muted"></i></span>
                            <input type="text" name="AdiSoyadi" value="{{ old('AdiSoyadi') }}" class="form-control" placeholder="Örn: Ahmet Yılmaz" required>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label fw-bold text-dark small">Satış Platformu</label>
                        <div class="input-group merged-group">
                            <span class="input-group-text"><i class="fa-solid fa-shop text-muted"></i></span>
                            <select name="PazaryeriID" id="pazaryeriSelect" class="form-select" required>
                                <option value="">Platform Seçiniz...</option>
                                @foreach($pazaryerleri as $p)
                                    <option value="{{ $p->id }}" @selected(old('PazaryeriID') == $p->id)>
                                        {{ $p->Ad }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>

                {{-- DİNAMİK ALAN: USA SİPARİŞİ --}}
                <div id="usaBox" class="mb-4" style="display: none;">
                    <div class="p-3 bg-primary bg-opacity-10 border border-primary border-opacity-25 rounded-3 d-flex align-items-center">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" name="isUSA" id="isUSA" value="1" style="width: 3em; height: 1.5em; cursor: pointer;">
                            <label class="form-check-label fw-bold ms-3 text-primary" for="isUSA" style="cursor: pointer;">
                                <i class="fa-solid fa-flag-usa me-1"></i> Bu sipariş Amerika'ya (USA) gönderilecek
                            </label>
                        </div>
                    </div>
                    <div class="form-text small mt-1 ms-1 text-primary opacity-75">
                        <i class="fa-solid fa-info-circle me-1"></i>Vergi hesaplamaları USA oranlarına göre yapılır.
                    </div>
                </div>

                <hr class="border-secondary opacity-10 my-4">

                {{-- BÖLÜM 2: ÜRÜN BİLGİLERİ --}}
                <h6 class="fw-bold text-secondary text-uppercase ls-1 mb-3">Ürün Bilgileri</h6>

                <div class="row g-4">
                    <div class="col-md-5">
                        <label class="form-label fw-bold text-dark small">Stok Kodu (SKU)</label>
                        <div class="input-group merged-group">
                            <span class="input-group-text"><i class="fa-solid fa-barcode text-muted"></i></span>
                            <input type="text" name="UrunKodu" value="{{ old('UrunKodu') }}" class="form-control" placeholder="Örn: CH061" required>
                        </div>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label fw-bold text-dark small">Adet</label>
                        <div class="input-group merged-group">
                            <span class="input-group-text"><i class="fa-solid fa-layer-group text-muted"></i></span>
                            <input type="number" name="Adet" min="1" value="{{ old('Adet', 1) }}" class="form-control text-center fw-bold" required>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label fw-bold text-dark small">Satış Fiyatı (Birim)</label>
                        <div class="input-group merged-group">
                            {{-- Para birimi simgesini input'un sağına aldım, daha şık durur --}}
                            <input type="number" step="0.01" name="SatisFiyati" value="{{ old('SatisFiyati') }}" class="form-control fw-bold" placeholder="0.00" required>
                            <span class="input-group-text fw-bold text-dark bg-white border-start-0" id="currencySymbol">₺</span>
                        </div>
                        <div class="form-text x-small ms-1">Kuruşları nokta (.) ile ayırın.</div>
                    </div>
                </div>

                <div class="mt-4">
                    <label class="form-label fw-bold text-dark small">Sipariş Tarihi</label>
                    <div class="input-group merged-group">
                        <span class="input-group-text"><i class="fa-regular fa-calendar-days text-muted"></i></span>
                        <input type="datetime-local" name="Tarih" class="form-control" value="{{ now()->format('Y-m-d\TH:i') }}">
                    </div>
                </div>

                {{-- AKSİYON BUTONU --}}
                <div class="d-grid mt-5">
                    <button type="submit" class="btn btn-dark py-3 fw-bold shadow-sm rounded-3 transition-hover">
                        <i class="fa-solid fa-floppy-disk me-2"></i> SİPARİŞİ KAYDET
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>

{{-- ÖZEL CSS: KUTULARI BİRLEŞTİRME VE DÜZELTME --}}
<style>
    .ls-1 { letter-spacing: 1px; }

    /* --- MERGED GROUP (BİRLEŞİK KUTU) CSS --- */
    /* 1. Çerçeveyi dıştaki DIV'e veriyoruz */
    .merged-group {
        border: 1px solid #ced4da;
        border-radius: 0.5rem; /* Köşeleri yuvarla */
        background-color: #fff;
        overflow: hidden; /* Taşmaları gizle */
        transition: all 0.2s ease-in-out;
    }

    /* 2. Odaklanıldığında (içindeki inputa tıklanınca) DIŞ KUTUYU boyuyoruz */
    .merged-group:focus-within {
        border-color: #212529; /* Siyah çerçeve */
        box-shadow: 0 0 0 0.25rem rgba(33, 37, 41, 0.1); /* Hafif gölge */
    }

    /* 3. İçerdeki Input ve İkonun kenarlıklarını SIFIRLIYORUZ */
    .merged-group .form-control,
    .merged-group .form-select,
    .merged-group .input-group-text {
        border: none !important;
        box-shadow: none !important; /* Bootstrap varsayılan gölgesini iptal et */
        background-color: transparent; /* Arka plan şeffaf olsun ki dış kutu görünsün */
    }

    /* 4. İkonun arka planını beyaz yap (isteğe bağlı, şeffaf da kalabilir) */
    .merged-group .input-group-text {
        background-color: #fff; 
        padding-right: 10px;
    }

    /* 5. Buton Hover Efekti */
    .transition-hover:hover {
        transform: translateY(-2px);
        box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.15) !important;
    }
</style>

{{-- JAVASCRIPT --}}
<script>
document.addEventListener("DOMContentLoaded", function() {
    const dropdown = document.getElementById('pazaryeriSelect');
    const usaBox = document.getElementById('usaBox');
    const currencySymbol = document.getElementById('currencySymbol');

    function kontrolEt() {
        const selectedText = dropdown.options[dropdown.selectedIndex].text.toLowerCase();
        const selectedVal = dropdown.value;

        // Etsy kontrolü
        if (selectedVal == "3" || selectedText.includes("etsy")) {
            usaBox.style.display = "block";
            setTimeout(() => { usaBox.style.opacity = "1"; }, 10);
            currencySymbol.innerText = "$"; 
        } else {
            usaBox.style.display = "none";
            usaBox.style.opacity = "0";
            currencySymbol.innerText = "₺"; 
        }
    }

    dropdown.addEventListener("change", kontrolEt);
    kontrolEt();
});
</script>
@endsection