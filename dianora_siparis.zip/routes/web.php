<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

use App\Http\Controllers\SiparisController;
use App\Http\Controllers\UrunController;
use App\Http\Controllers\AyarController;
use App\Http\Controllers\KategoriController;
use App\Http\Controllers\FiyatController;
use App\Http\Controllers\PazaryeriController;
use App\Http\Controllers\ManuelSiparisController;


// Ana yönlendirme
Route::redirect('/', '/siparisler');


// 🔹 Siparişler
Route::get('/siparisler', [SiparisController::class, 'index'])->name('siparisler.index');
Route::get('/istatistikler', [SiparisController::class, 'istatistikler'])->name('istatistikler');

Route::post('/siparis/ekstra-ekle', [SiparisController::class, 'ekstraEkle'])->name('siparis.ekstraEkle');

// Ürün Detay
Route::get('/urun-detay/{siparis}/{stok}', [UrunController::class, 'detay'])
     ->name('urun.detay');

Route::get('/siparis-guncelle-ve-kar', [UrunController::class, 'siparisGuncelleVeKar'])
     ->name('siparis.guncelleVeKar');

// Manuel sipariş durumunu güncelleme rotası
Route::post('/siparisler/durum-guncelle/{id}', [SiparisController::class, 'durumGuncelle'])->name('siparis.durumGuncelle');


// 🔹 Ayarlar

// 🔹 Kategoriler
Route::get('/kategoriler', [KategoriController::class, 'index'])->name('kategoriler.index');
Route::post('/kategoriler/guncelle', [KategoriController::class, 'guncelle'])->name('kategoriler.guncelle');


// 🔹 Fiyat Hesaplama
Route::get('/fiyat', [FiyatController::class, 'index'])->name('fiyat.index'); // Sayfayı açar

// AJAX İşlemleri (Yeni eklenenler)
Route::get('/fiyat/urun-getir', [FiyatController::class, 'urunGetir'])->name('fiyat.urunGetir'); // Ürün bilgilerini çeker
Route::post('/fiyat/hesapla', [FiyatController::class, 'hesapla'])->name('fiyat.hesapla');      // Hesaplama yapar



// 🔹 2. PAZARYERİ ve AYAR İŞLEMLERİ (Ekle / Güncelle / Sil)
Route::get('/ayarlar', [AyarController::class, 'index'])->name('ayarlar.index');
Route::post('/ayarlar', [AyarController::class, 'guncelle'])->name('ayarlar.guncelle');

Route::post('/ayarlar/pazaryerleri', [PazaryeriController::class, 'store'])->name('pazaryeri.store');
Route::post('/ayarlar/pazaryerleri/{id}', [PazaryeriController::class, 'update'])->name('pazaryeri.update');
Route::delete('/ayarlar/pazaryerleri/{id}', [PazaryeriController::class, 'destroy'])->name('pazaryeri.destroy');

// 🔹 Manuel Sipariş Ekleme
Route::get('/siparisler/manuel-ekle', [ManuelSiparisController::class, 'create'])->name('siparisler.manuel.create');
Route::post('/siparisler/manuel-ekle', [ManuelSiparisController::class, 'store'])->name('siparisler.manuel.store');


Route::delete('/siparis-sil/{id}', [SiparisController::class, 'destroy'])->name('manuel.sil');



Route::get('/welcome', function () {
    return view('welcome');
});